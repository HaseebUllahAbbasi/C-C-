// C++ Program for Huffman Coding
// using Priority Queue
#include <iostream>
#include <queue>
#include <fstream>
#include <string>
using namespace std;


// Maximum Height of Huffman Tree.
#define MAX_SIZE 100

class HuffmanTreeNode
{
    public:
    // Stores character
    char data;

    // Stores frequency of
    // the character
    int freq;

    // Left child of the
    // current node
    HuffmanTreeNode* left;

    // Right child of the
    // current node
    HuffmanTreeNode* right;

    // Initializing the
    // current node
    HuffmanTreeNode(char character,
                    int frequency)
    {
        data = character;
        freq = frequency;
        left = right = NULL;
    }
};

// Custom comparator class
class Compare {
public:
    bool operator()(HuffmanTreeNode* a,
                    HuffmanTreeNode* b)
    {
        // Defining priority on
        // the basis of frequency
        return a->freq > b->freq;
    }
};

// Function to generate Huffman
// Encoding Tree
HuffmanTreeNode* generateTree(priority_queue<HuffmanTreeNode*,vector<HuffmanTreeNode*>,Compare> pq)
{

    // We keep on looping till
    // only one node remains in
    // the Priority Queue
    while (pq.size() != 1) {

        // Node which has least
        // frequency
        HuffmanTreeNode* left = pq.top();

        // Remove node from
        // Priority Queue
        pq.pop();

        // Node which has least
        // frequency
        HuffmanTreeNode* right = pq.top();

        // Remove node from
        // Priority Queue
        pq.pop();

        // A new node is formed
        // with frequency left->freq
        // + right->freq

        // We take data as '$'
        // because we are only
        // concerned with the
        // frequency
        HuffmanTreeNode* node = new HuffmanTreeNode('$',
                                  left->freq + right->freq);
        node->left = left;
        node->right = right;

        // Push back node
        // created to the
        // Priority Queue
        pq.push(node);
    }

    return pq.top();
}

// Function to print the
// huffman code for each
// character.

// It uses arr to store the codes
	int total_b = 0; 

void printCodes(HuffmanTreeNode* root,
                int arr[], int top)
{
    
    // Assign 0 to the left node
    // and recur
    if (root->left) {
        arr[top] = 0;
        printCodes(root->left,
                   arr, top + 1);
    }

    // Assign 1 to the right
    // node and recur
    if (root->right) {
        arr[top] = 1;
        printCodes(root->right, arr, top + 1);
    }

    // If this is a leaf node,
    // then we print root->data

    // We also print the code
    // for this character from arr
    if (!root->left && !root->right) {
        cout << root->data << " ";

        for (int i = 0; i < top; i++) {
            cout << arr[i];
            total_b+=sizeof(arr[i]);
        	//cout<<sizeof(arr[i]);
        }
        cout << endl;
    }
}

void HuffmanCodes(char data[],
                  int freq[], int size)
{

    // Declaring priority queue
    // using custom comparator
    priority_queue<HuffmanTreeNode*,
                   vector<HuffmanTreeNode*>,
                   Compare>
        pq;

    // Populating the priority
    // queue
    for (int i = 0; i < size; i++) {
        HuffmanTreeNode* newNode
            = new HuffmanTreeNode(data[i], freq[i]);
        pq.push(newNode);
    }

    // Generate Huffman Encoding
    // Tree and get the root node
    HuffmanTreeNode* root = generateTree(pq);

    // Print Huffman Codes
    int arr[MAX_SIZE], top = 0;
    printCodes(root, arr, top);
}
// Driver Code
int main(int argc, char** argv) 
{  
	string str = "";
    
	string line;
   ifstream myfile ("example.txt");
   if (myfile.is_open())
  	{
	    while ( getline (myfile,line) )
	    {
	 //     cout << line << '\n';
	    	str+=line;
	    }
	    myfile.close();
  	}
  	else
  	{
  		cout<<"unable to open";
  	}
  	int total_bits = str.length();
  	cout<<"the total_bits are "<<total_bits*8<<endl; 
    
    //for (int i = 1; i < argc; ++i)
    //{
     //   str+=argv[i];
    //}
    
    //cout<<endl;
    //cout<<"data in the string is "<<data<<endl;

	/*

    char data[] = { 'a', 'b', 'c', 'd', 'e', 'f' }; 
    int freq[] = { 5, 9, 12, 13, 16, 45 }; 
    int size = sizeof(data) / sizeof(data[0]); 
    HuffmanCodes(data, freq, size); 
    return 0; 
	*/
	int i = 0, alphabet[26] = {0}, j;
   while (str[i] != '\0') {
      if (str[i] >= 'a' && str[i] <= 'z') {
         j = str[i] - 'a';
         ++alphabet[j];
      }
      ++i;
   }
   //cout<<"Frequency of all alphabets in the string is:"<<endl;
   int size = 0;
   for (i = 0; i < 26; i++)
   if(alphabet[i]!=0)
   {
   	size++;
   	//cout<< char(i + 'a')<<" : "<< alphabet[i]<< endl;	
   }
   
   char data[size];
   int freq[size];
   int count = 0;  
   for (i = 0; i < 26; i++)
   if(alphabet[i]!=0)
   {
   	freq[count] = alphabet[i];
   	data[count] = char(i + 'a'); 
   	//cout<< data[count]<<" : "<< freq[count]<< endl;	
   	count++;
   }
   HuffmanCodes(data,freq,count);
   cout<<"bits after compression: "<<total_b + (count*8)<<endl;
   
   cout<<"compression rate: "<<(total_bits*8.0 - total_b)*100/(total_bits*8);

   cout<<endl;

}

