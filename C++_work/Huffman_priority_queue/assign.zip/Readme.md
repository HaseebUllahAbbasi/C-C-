# Huffman Algorithm implementation
*Huffman Algorithm is used to compress the data and save the size ***
***
*Huffman make use of the tree and priority queue data structures to achieve the compression of bits  *
***
# How to Run:
*Use make command to run the code *
or the code can be compiled manually using the command "gcc HuffmanCoder.cpp -o task"
then use ./ task example.txt to test the file
*** 
