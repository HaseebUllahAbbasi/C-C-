
using namespace std;
class Date
{

public:
    int month, day,year;
};
