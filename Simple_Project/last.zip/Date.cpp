#include<iostream>
#include "Date.h"
using namespace std;
void Date :: display_Date() 
{
	cout<<month<<" "<<day<<" "<<year<<endl;

};