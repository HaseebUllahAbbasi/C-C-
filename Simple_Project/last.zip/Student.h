using namespace std;

class Student
{

public:
    string first_name, last_name, standing, date_of_birth;
    int credits, id;
    double gpa;
    void display_student();
};
